const LoadingBubble = () => {
  return <div className="loader"></div>;
};

export default LoadingBubble;
